-- ============================================
-- 2- Catalogo
-- ============================================
use pacienteHistoriaclinica;

-- completamos las tablas provincia, especialidad, o_social y medicamentos.
INSERT INTO provincia (provincia) VALUES
('Buenos Aires'), ('Catamarca'), ('Chaco'), ('Chubut'),
('Córdoba'), ('Corrientes'), ('Entre Ríos'), ('Formosa'),
('Jujuy'), ('La Pampa'), ('La Rioja'), ('Mendoza'),
('Misiones'), ('Neuquén'), ('Río Negro'),
('Salta'), ('San Juan'), ('San Luis'),
('Santa Cruz'), ('Santa Fe'), ('Santiago del Estero'),
('Tierra del Fuego'), ('Tucumán');

INSERT INTO especialidad (especialidad) VALUES
('Clínica Médica'), ('Medicina Interna'), ('Pediatría'), ('Ginecología y Obstetricia'),
('Cardiología'), ('Dermatología'), ('Neurología'), ('Oftalmología'),
('Otorrinolaringología'), ('Traumatología y Ortopedia'), ('Cirugía General'), ('Medicina General y Familiar'),
('Psiquiatría'), ('Endocrinología'), ('Nefrología'),
('Gastroenterología'), ('Oncología'), ('Urología'),
('Neumonología'), ('Reumatología'), ('Infectología');

INSERT INTO o_social (nombre) VALUES
('OSDE'), ('Swiss Medical'), ('Galeno'), ('Omint'),
('Medifé'), ('OSPIM'), ('OSECAC'), ('OSPE'),
('OSPLAD'), ('IOMA'), ('PAMI'), ('OSUTHGRA'),
('OSDEPYM'), ('OSPAT'), ('OSPERYHRA'),
('OSPRERA'), ('OSTEL'), ('OSMATA'),
('OSSEG'), ('IOSFA'), ('DASPU');

INSERT INTO medicamentos (medicamento) VALUES
('Paracetamol'), ('Ibuprofeno'), ('Amoxicilina'), ('Omeprazol'),
('Enalapril'), ('Losartán'), ('Metformina'), ('Atenolol'),
('Diclofenac'), ('Loratadina'), ('Ácido acetilsalicílico'), ('Levotiroxina'),
('Alprazolam'), ('Sertralina'), ('Clonazepam'),
('Furosemida'), ('Hidroclorotiazida'), ('Amoxicilina + Ácido clavulánico'),
('Salbutamol'), ('Prednisona'), ('Cefalexina'),
('Tramadol'), ('Bisoprolol'), ('Rosuvastatina'), ('Simvastatina'),
('Escitalopram'), ('Diazepam'), ('Clopidogrel'), ('Amlodipina'),
('Ranitidina'), ('Metronidazol'), ('Naproxeno'),
('Lorazepam'), ('Cetirizina'), ('Azitromicina'),
('Fluoxetina'), ('Insulina'), ('Glibenclamida'),
('Salbutamol + Ipratropio'),
('Montelukast'), ('Diclofenac + B1+B6+B12'), ('Meloxicam'),
('Ketorolac'), ('Dexametasona'), ('Domperidona'),
('Lorazepam'), ('Betametasona'), ('Amiodarona');

-- Creamos tablas auxiliares para rellenar la base (nombre_aux, apellido_auc, antecedentes_aux, 
-- localidades_aux, calles_aux)
CREATE TABLE nombres_aux (
id INT AUTO_INCREMENT PRIMARY KEY,
nombre VARCHAR(100) NOT NULL
);
INSERT INTO nombres_aux (nombre) VALUES
('Sofía'),('Mateo'),('Valentina'),('Nicolás'),('Martina'),('Juan'),('Camila'),('Lucas'),('Florencia'),
('Tomás'),('Julieta'),('Santiago'),('Catalina'),('Benjamín'),('Milagros'),('Joaquín'),('Lucía'),('Franco'),
('Morena'),('Lautaro'),('Ignacio'),('Mía'),('Facundo'),('Delfina'),('Agustín'),('Paula'),('Ramiro'),('Bianca'),
('Bruno'),('Emilia'),('Gonzalo'),('Alma'),('Emiliano'),('Renata'),('Simón'),('Abril'),('Thiago'),('Lara'),
('Máximo'),('Josefina'),('Enzo'),('Malena'),('Esteban'),('Antonella'),('Kevin'),('Pilar'),('Juan Pablo'),
('Candela'),('Ezequiel'),('Alma'),('Agustina'),('Sebastián'),('Milena'),('Leandro'),('Carla'),('Franco'),
('Elena'),('Valentino'),('Celeste'),('Tobias'),('Victoria'),('Ramiro'),('Guadalupe'),('Damián'),('Francesca'),
('Nicolás'),('Luna'),('Luciano'),('Alma'),('Alan'),('Zoe'),('Andrés'),('Isabella'),('Rodrigo'),('Aitana'),('Diego'),
('Valeria'),('Adrián'),('Carolina'),('Samuel'),('Jazmín'),('Gonzalo'),('Abril'),('Lautaro'),('Alma');

CREATE TABLE apellidos_aux (
id INT AUTO_INCREMENT PRIMARY KEY,
apellido VARCHAR(100) NOT NULL
);
INSERT INTO apellidos_aux (apellido) VALUES
('González'),('Rodríguez'),('López'),('Fernández'),('Pérez'),('García'),('Sánchez'),('Romero'),('Díaz'),('Torres'),
('Ramírez'),('Herrera'),('Flores'),('Alvarez'),('Jiménez'),('Acosta'),('Rojas'),('Morales'),('Navarro'),('Molina'),
('Blanco'),('Medina'),('Vega'),('Suárez'),('Domínguez'),('Ponce'),('Cabrera'),('Aguilar'),('Silva'),('Ramos'),('Castillo'),
('Herrera'),('Campos'),('Márquez'),('Benítez'),('Vázquez'),('Cabrera'),('Bravo'),('Contreras'),('Ortiz'),('Figueroa'),
('Moreno'),('Delgado'),('Peralta'),('Correa'),('Luna'),('Carrizo'),('Quiroga'),('Bustos'),('Cardozo'),('Escobar'),('Aguirre'),
('Cornejo'),('Barrios'),('Lucero'),('Maidana'),('Godoy'),('Giménez'),('Romero'),('Valdez'),('Cabrera'),('Ferreyra'),('Ochoa'),
('Cáceres'),('Flores'),('Reynoso'),('Bravo'),('Toledo'),('Navarro'),('Palacios'),('Montenegro'),('Pereyra'),('Moyano'),('Britos'),
('Esquivel'),('Olivera'),('Rivero'),('Cardoso'),('Bustamante'),('Villalba'),('Funes'),('Segovia'),('Ibarra'),('Benitez'),('Sosa');

CREATE TABLE antecedentes_aux (
id INT AUTO_INCREMENT PRIMARY KEY,
antecedente VARCHAR(100) NOT NULL
);
INSERT INTO antecedentes_aux (antecedente) VALUES
('Asma'),(' Hipertension'),(' Alergia'),(' Sin antecedentes'),(' Diabetes'),(' Sin antecedentes'),('Arritmia'),
('Cancer de mamas'),(' Hepatitis'),(' Chagas'),(' Sin antecedentes'),(' Migranña'),(' Sin antecedentes');

CREATE TABLE localidades_aux (
id INT AUTO_INCREMENT PRIMARY KEY,
localidad VARCHAR(100) NOT NULL
);
INSERT INTO localidades_aux (localidad) VALUES
('La Penca'),('Las Golondrinas'),('El Hoyo'),('Villa Traful'),('Los Antiguos'),('Villa La Angostura'),
('El Durazno'),('Villa Pehuenia'),('Antofagasta de la Sierra'),('Telsen'),('Estación Yuquerí'),
('El Soberbio'),('Aldea Beleiro'),('Lago Puelo'),('Las Grutas'),('San Antonio de Areco'),('Capilla del Monte'),
('Ongamira'),('Villa Quilino'),('Cachi'),('Iruya'),('Angastaco'),('Vinchina'),('Ischigualasto'),('La Leonesa'),
('El Impenetrable'),('Sierra Grande'),('Camarones'),('Las Lajas'),('Daireaux'),('Puan'),('Coronel Dorrego'),
('Sierra de la Ventana'),('Claromecó'),('Uribelarrea'),('San Javier'),('Romang'),('Moisés Ville'),('San Gregorio'),
('Carhué'),('Guaminí'),('La Viña'),('San Carlos'),('Campo Quijano'),('El Potrero'),('Tolar Grande'),
('Fray Mamerto Esquiú'),('El Rodeo'),('El Carril'),('Tilcara');

CREATE TABLE calles_aux (
id INT AUTO_INCREMENT PRIMARY KEY,
calle_nro VARCHAR(100) NOT NULL
);
INSERT INTO calles_aux (calle_nro) VALUES
('Rivadavia'),('Belgrano'),('San Martín'),('Mitre'),('9 de Julio'),('Corrientes'),('Córdoba'),
('Santa Fe'),('Sarmiento'),('Callao'),('Jujuy'),('Salta'),('Maipú'),('Sucre'),('Chacabuco'),
('Pueyrredón'),('Balcarce'),('Junín'),('Lavalle'),('Esmeralda'),('Bolívar'),('Moreno'),('Alsina'),
('Viamonte'),('Talcahuano'),('Rodríguez'),('Avellaneda'),('Caseros'),('Garay'),('Brown'),('Saavedra'),
('Zuviría'),('Güemes'),('Pedernera'),('Lamadrid'),('Alberdi'),('Roca'),('Colón'),('España'),('Italia'),
('Liniers'),('Pringles'),('Fray Justo'),('Pellegrini'),(' Zapiola'),('O Higgins'),('Pampa'),('Las Heras'),
('Castro'),('Chile');