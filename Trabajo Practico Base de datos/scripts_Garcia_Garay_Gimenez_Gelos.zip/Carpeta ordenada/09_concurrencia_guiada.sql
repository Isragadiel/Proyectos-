-- =====================================================
-- 09_concurrencia_guiada.sql
-- Etapa 5 - Concurrencia y Transacciones
-- =====================================================

USE pacienteHistoriaClinica;

-- =====================================================
-- 1. Simulación de bloqueos y deadlocks
-- =====================================================

-- Sesión 1
START TRANSACTION;
UPDATE paciente SET nombre = 'Juan (bloqueado)' WHERE id = 1;
-- No hacer COMMIT todavía

-- Sesión 2
START TRANSACTION;
UPDATE paciente SET nombre = 'Pedro (conflicto)' WHERE id = 2;
UPDATE paciente SET nombre = 'Juan (deadlock)' WHERE id = 1;

-- Sesión 1 (continúa)
UPDATE paciente SET nombre = 'Pedro (deadlock)' WHERE id = 2;
COMMIT;

-- Resultado esperado:
-- Error 1213: Deadlock found when trying to get lock; try restarting transaction


-- =====================================================
-- 2. Procedimiento con manejo de deadlock y retry
-- =====================================================
-- SESIÓN 1 → crea el bloqueo
-- Esta sesión simula que un usuario está editando un registro y todavía no liberó el lock.
USE pacienteHistoriaClinica;
START TRANSACTION;
UPDATE paciente SET nombre = 'Juan (bloqueado)' WHERE id = 1;
-- No hagas COMMIT todavía

-- SSESIÓN 2 → crea y ejecuta el procedimiento
-- Crear el procedimiento (solo una vez):
DROP PROCEDURE IF EXISTS ActualizarPacienteRetry;

DELIMITER $$

CREATE PROCEDURE ActualizarPacienteRetry(IN p_id INT, IN p_nombre VARCHAR(50))
BEGIN
    DECLARE retries INT DEFAULT 0;
    DECLARE exit_loop BOOL DEFAULT FALSE;

    WHILE retries < 2 AND NOT exit_loop DO
        BEGIN
            DECLARE CONTINUE HANDLER FOR 1213
            BEGIN
                SET retries = retries + 1;
                DO SLEEP(1); -- Espera breve antes del reintento
            END;

            START TRANSACTION;
                UPDATE paciente SET nombre = p_nombre WHERE id = p_id;
            COMMIT;

            SET exit_loop = TRUE;
        END;
    END WHILE;
END$$

DELIMITER ;
-- Ejecutar el procedimiento (mientras la Sesión 1 sigue bloqueando)
CALL ActualizarPacienteRetry(1, 'Juan Retried');

-- Puede aparecer:
-- Error Code: 1205. Lock wait timeout exceeded; try restarting transaction
-- o, si liberás el lock justo a tiempo, el procedimiento se completa exitosamente.

-- =====================================================
-- 3. Comparación de niveles de aislamiento
-- =====================================================

-- READ COMMITTED
-- SESIÓN 1
SET SESSION TRANSACTION ISOLATION LEVEL READ COMMITTED;
START TRANSACTION;
SELECT nombre FROM paciente WHERE id = 1;

-- (En otra sesión ejecutar:)
UPDATE paciente SET nombre = 'Cambio visible en READ COMMITTED' WHERE id = 1; COMMIT;
SELECT nombre FROM paciente WHERE id = 1;
COMMIT;

-- Volvé a Sesión 1
SELECT nombre FROM paciente WHERE id = 1;
COMMIT;

-- Resultado esperado:
-- El nuevo valor 'Cambio visible en READ COMMITTED' se ve inmediatamente aunque la sesión 1 todavía no haya hecho COMMIT.
 
-- REPEATABLE READ
-- Sesión 1
SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ;
START TRANSACTION;
SELECT nombre FROM paciente WHERE id = 1;
-- NO hagas COMMIT

-- (En otra sesión ejecutar:)
UPDATE paciente SET nombre = 'Cambio invisible en REPEATABLE READ' WHERE id = 1; COMMIT;
SELECT nombre FROM paciente WHERE id = 1;
COMMIT;

-- Sesión 1
SELECT nombre FROM paciente WHERE id = 1;
COMMIT;
-- Resultado esperado:
 -- Vas a seguir viendo el valor anterior, no el nuevo.
 -- Solo después de hacer COMMIT o iniciar una nueva transacción lo verás actualizado.
-- =====================================================
-- 4. Observaciones finales
-- =====================================================
-- En las pruebas de concurrencia se reprodujo un deadlock (Error 1213).
-- El procedimiento con retry permitió reintentar exitosamente la transacción.
-- READ COMMITTED muestra cambios confirmados entre transacciones.
-- REPEATABLE READ mantiene una vista consistente hasta el commit
