-- ============================================
-- VISTAS
-- ============================================

-- VISTA 1: Vista resumen de pacientes con información completa
CREATE OR REPLACE VIEW v_pacientes_completo AS
SELECT 
    pac.id,
    pac.dni,
    CONCAT(pac.apellido, ', ', pac.nombre) AS nombre_completo,
    TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) AS edad,
    pac.email,
    pac.persona_contacto,
    pac.telefono_contacto,
    os.nombre AS obra_social,
    hc.nro_historia,
    hc.grupo_sangre,
    hc.antecedentes,
    CONCAT(dom.direccion, ', ', loc.localidad, ', ', prov.provincia) AS domicilio_completo
FROM paciente pac
LEFT JOIN historiaClinica hc ON pac.id = hc.id_paciente AND hc.eliminado = 0
LEFT JOIN o_social os ON hc.id_o_social = os.id AND os.eliminado = 0
LEFT JOIN domicilio dom ON pac.id = dom.id_paciente AND dom.eliminado = 0
LEFT JOIN localidad loc ON dom.id_localidad = loc.id AND loc.eliminado = 0
LEFT JOIN provincia prov ON loc.id_provincia = prov.id AND prov.eliminado = 0
WHERE pac.eliminado = 0;

-- VISTA 2: Vista estadísticas por profesional
CREATE OR REPLACE VIEW v_estadisticas_profesional AS
SELECT 
    prof.id,
    CONCAT(prof.apellido, ', ', prof.nombre) AS profesional,
    e.especialidad,
    COUNT(DISTINCT i.id_paciente) AS pacientes_atendidos,
    COUNT(i.id) AS total_intervenciones,
    COUNT(mi.id_medicamento) AS recetas_emitidas,
    DATE_FORMAT(MIN(i.fecha), '%d/%m/%Y') AS primera_atencion,
    DATE_FORMAT(MAX(i.fecha), '%d/%m/%Y') AS ultima_atencion
FROM profesional prof
INNER JOIN especialidad e ON prof.id_especialidad = e.id
LEFT JOIN intervenciones i ON prof.id = i.id_profesional AND i.eliminado = 0
LEFT JOIN medicamento_intervenciones mi ON i.id = mi.id_intervencion
WHERE prof.eliminado = 0 AND e.eliminado = 0
GROUP BY prof.id, prof.apellido, prof.nombre, e.especialidad;

-- Ejemplo de uso de las vistas:
SELECT * FROM v_pacientes_completo WHERE edad > 65;
SELECT * FROM v_estadisticas_profesional ORDER BY total_intervenciones DESC;