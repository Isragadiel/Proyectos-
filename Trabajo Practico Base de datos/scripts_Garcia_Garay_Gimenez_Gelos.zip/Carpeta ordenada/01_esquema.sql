-- ============================================
-- ESQUEMAS
-- Creacion de la base de datos y las tablas principales
-- ============================================
CREATE database pacienteHistoriaClinica;
use pacienteHistoriaClinica;
CREATE TABLE paciente (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
apellido varchar(50) NOT NULL,
nombre varchar(50) NOT NULL,
dni varchar(15) NOT NULL unique,
fecha_nac DATE NOT NULL,
email varchar(50),
persona_contacto varchar(50) NOT NULL,
telefono_contacto varchar(30) NOT NULL,
CONSTRAINT chk_paciente_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE o_social (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
nombre varchar(100) NOT NULL,
CONSTRAINT chk_OS_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE historiaClinica (
id_paciente INT primary key NOT NULL,
eliminado boolean NOT NULL default false,
nro_historia varchar(20) NOT NULL unique,
grupo_sangre varchar(10) NOT NULL,
id_o_social int NOT NULL,
antecedentes text NOT NULL,
observaciones text NOT NULL,
CONSTRAINT fk_HC_paciente FOREIGN KEY (id_paciente) REFERENCES paciente (id) ON
DELETE restrict,
CONSTRAINT fk_HC_osocial FOREIGN KEY (id_o_social) REFERENCES o_social (id) ON
DELETE restrict,
CONSTRAINT chk_HC_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE especialidad (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
especialidad varchar(100) NOT NULL,
CONSTRAINT chk_espe_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE profesional (

id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
nombre varchar(50) NOT NULL,
apellido varchar(50) NOT NULL,
id_especialidad INT NOT NULL,
CONSTRAINT fk_profe_especialidad FOREIGN KEY (id_especialidad) REFERENCES
especialidad (id) ON DELETE restrict,
CONSTRAINT chk_profe_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE intervenciones (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
id_paciente INT NOT NULL,
fecha DATETIME DEFAULT now() NOT NULL,
id_profesional INT NOT NULL,
detalle TEXT NOT NULL,
CONSTRAINT fk_inter_paciente FOREIGN KEY (id_paciente) REFERENCES paciente (id) ON
DELETE restrict,
CONSTRAINT fk_inter_profesional FOREIGN KEY (id_profesional) REFERENCES profesional
(id) ON DELETE restrict,
CONSTRAINT chk_inter_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE medicamentos (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
medicamento varchar(100) NOT NULL,
CONSTRAINT chk_medi_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE medicamento_intervenciones (
id_medicamento INT NOT NULL,
id_intervencion INT NOT NULL,
PRIMARY KEY (id_medicamento, id_intervencion),
CONSTRAINT fk_MI_medicamento FOREIGN KEY (id_medicamento) REFERENCES
medicamentos (id) ON DELETE cascade,
CONSTRAINT fk_MI_intervencion FOREIGN KEY (id_intervencion) REFERENCES
intervenciones (id) ON DELETE cascade);
CREATE TABLE telefono (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
numero varchar(20) NOT NULL,
CONSTRAINT chk_tel_eliminado CHECK (eliminado IN (0,1)));

CREATE TABLE telefono_paciente (
id_paciente INT NOT NULL,
id_telefono INT NOT NULL,
PRIMARY KEY (id_paciente, id_telefono),
CONSTRAINT fk_TP_telefono FOREIGN KEY (id_telefono) REFERENCES telefono (id) ON
DELETE cascade,
CONSTRAINT fk_TP_paciente FOREIGN KEY (id_paciente) REFERENCES paciente (id) ON
DELETE cascade);
CREATE TABLE provincia (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
provincia varchar(50) NOT NULL,
CONSTRAINT chk_prov_eliminado CHECK (eliminado IN (0,1)));
CREATE TABLE localidad (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
localidad varchar(100) NOT NULL,
id_provincia INT NOT NULL,
CONSTRAINT fk_loc_provincia FOREIGN KEY (id_provincia) REFERENCES provincia (id) ON
DELETE restrict,
CONSTRAINT chk_loc_eliminado CHECK ( eliminado IN (0,1)));
CREATE TABLE domicilio (
id INT auto_increment primary key NOT NULL,
eliminado boolean NOT NULL default false,
id_paciente INT NOT NULL,
direccion varchar(100) NOT NULL,
id_localidad INT NOT NULL,
CONSTRAINT fk_dom_paciente FOREIGN KEY (id_paciente) REFERENCES paciente (id) ON
DELETE cascade,
CONSTRAINT fk_dom_localidad FOREIGN KEY (id_localidad) REFERENCES localidad (id)
ON DELETE restrict,
CONSTRAINT chk_dom_eliminado CHECK ( eliminado IN (0,1)));
DELIMITER $$
CREATE TRIGGER trg_validar_fecha_nacimiento
BEFORE INSERT ON paciente
FOR EACH ROW
BEGIN

IF NEW.fecha_nac > CURDATE() THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La fecha de nacimiento no puede
ser una fecha futura.';
END IF;
END$$
CREATE TRIGGER trg_validar_fecha
BEFORE INSERT ON intervenciones
FOR EACH ROW
BEGIN
IF NEW.fecha > CURDATE() THEN
SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La fecha de intervencion no puede
ser una fecha futura.';
END IF;
END$$
DELIMITER ;