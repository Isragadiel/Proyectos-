-- ============================================
-- CONSULTAS AVANZADAS Y REPORTES
-- ============================================

-- 1. REPORTE: Pacientes por Obra Social con cantidad de intervenciones
-- (JOIN + GROUP BY + ORDER BY)
SELECT 
    os.nombre AS obra_social,
    COUNT(DISTINCT hc.id_paciente) AS total_pacientes,
    COUNT(i.id) AS total_intervenciones,
    ROUND(COUNT(i.id) / COUNT(DISTINCT hc.id_paciente), 2) AS promedio_intervenciones_por_paciente
FROM o_social os
INNER JOIN historiaClinica hc ON os.id = hc.id_o_social
LEFT JOIN intervenciones i ON hc.id_paciente = i.id_paciente AND i.eliminado = 0
WHERE os.eliminado = 0 AND hc.eliminado = 0
GROUP BY os.id, os.nombre
HAVING total_pacientes > 0
ORDER BY total_intervenciones DESC;

-- 2. REPORTE: Top 10 profesionales más activos por especialidad
-- (JOIN múltiples + GROUP BY + HAVING + LIMIT)
SELECT 
    e.especialidad,
    CONCAT(p.apellido, ', ', p.nombre) AS profesional,
    COUNT(i.id) AS cantidad_intervenciones,
    DATE_FORMAT(MIN(i.fecha), '%d/%m/%Y') AS primera_intervencion,
    DATE_FORMAT(MAX(i.fecha), '%d/%m/%Y') AS ultima_intervencion
FROM profesional p
INNER JOIN especialidad e ON p.id_especialidad = e.id
LEFT JOIN intervenciones i ON p.id = i.id_profesional AND i.eliminado = 0
WHERE p.eliminado = 0 AND e.eliminado = 0
GROUP BY e.especialidad, p.id, p.apellido, p.nombre
HAVING cantidad_intervenciones > 0
ORDER BY cantidad_intervenciones DESC
LIMIT 10;

-- 3. CONSULTA: Pacientes con múltiples intervenciones (Top pacientes más atendidos)
-- (JOIN + GROUP BY + HAVING + Subconsulta de fecha)
-- VERSION FLEXIBLE: Muestra todos los pacientes con al menos 2 intervenciones
SELECT 
    pac.dni,
    CONCAT(pac.apellido, ', ', pac.nombre) AS paciente,
    TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) AS edad,
    COUNT(i.id) AS total_intervenciones,
    DATE_FORMAT(MIN(i.fecha), '%d/%m/%Y') AS primera_consulta,
    DATE_FORMAT(MAX(i.fecha), '%d/%m/%Y') AS ultima_consulta,
    GROUP_CONCAT(DISTINCT e.especialidad ORDER BY e.especialidad SEPARATOR ', ') AS especialidades_consultadas
FROM paciente pac
INNER JOIN intervenciones i ON pac.id = i.id_paciente
INNER JOIN profesional prof ON i.id_profesional = prof.id
INNER JOIN especialidad e ON prof.id_especialidad = e.id
WHERE pac.eliminado = 0 
    AND i.eliminado = 0
GROUP BY pac.id, pac.dni, pac.apellido, pac.nombre, pac.fecha_nac
HAVING total_intervenciones >= 2
ORDER BY total_intervenciones DESC, ultima_consulta DESC;

-- 4. REPORTE: Medicamentos más recetados por especialidad
-- (JOIN múltiples + GROUP BY + Subconsulta)
SELECT 
    e.especialidad,
    m.medicamento,
    COUNT(mi.id_intervencion) AS veces_recetado,
    ROUND(COUNT(mi.id_intervencion) * 100.0 / 
        (SELECT COUNT(*) 
         FROM medicamento_intervenciones mi2
         INNER JOIN intervenciones i2 ON mi2.id_intervencion = i2.id
         INNER JOIN profesional p2 ON i2.id_profesional = p2.id
         WHERE p2.id_especialidad = e.id AND i2.eliminado = 0), 2) AS porcentaje
FROM especialidad e
INNER JOIN profesional prof ON e.id = prof.id_especialidad
INNER JOIN intervenciones i ON prof.id = i.id_profesional
INNER JOIN medicamento_intervenciones mi ON i.id = mi.id_intervencion
INNER JOIN medicamentos m ON mi.id_medicamento = m.id
WHERE e.eliminado = 0 AND prof.eliminado = 0 
    AND i.eliminado = 0 AND m.eliminado = 0
GROUP BY e.id, e.especialidad, m.id, m.medicamento
ORDER BY e.especialidad, veces_recetado DESC;

-- 5. CONSULTA: Pacientes sin intervenciones en los últimos 6 meses
-- (LEFT JOIN + WHERE NULL + Subconsulta)
SELECT 
    pac.dni,
    CONCAT(pac.apellido, ', ', pac.nombre) AS paciente,
    pac.email,
    pac.persona_contacto,
    pac.telefono_contacto,
    os.nombre AS obra_social,
    DATE_FORMAT(ultima_intervencion.fecha, '%d/%m/%Y') AS ultima_visita
FROM paciente pac
INNER JOIN historiaClinica hc ON pac.id = hc.id_paciente
INNER JOIN o_social os ON hc.id_o_social = os.id
LEFT JOIN (
    SELECT id_paciente, MAX(fecha) AS fecha
    FROM intervenciones
    WHERE eliminado = 0
    GROUP BY id_paciente
) ultima_intervencion ON pac.id = ultima_intervencion.id_paciente
WHERE pac.eliminado = 0 
    AND hc.eliminado = 0
    AND (ultima_intervencion.fecha IS NULL 
         OR ultima_intervencion.fecha < DATE_SUB(CURDATE(), INTERVAL 6 MONTH))
ORDER BY ultima_intervencion.fecha;

-- 6. REPORTE: Distribución de pacientes por rango etario y obra social
-- (CASE + GROUP BY + JOIN)
SELECT 
    CASE 
        WHEN TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) < 18 THEN 'Menor de 18'
        WHEN TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) BETWEEN 18 AND 30 THEN '18-30'
        WHEN TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) BETWEEN 31 AND 50 THEN '31-50'
        WHEN TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE()) BETWEEN 51 AND 70 THEN '51-70'
        ELSE 'Mayor de 70'
    END AS rango_edad,
    os.nombre AS obra_social,
    COUNT(*) AS cantidad_pacientes,
    ROUND(AVG(TIMESTAMPDIFF(YEAR, pac.fecha_nac, CURDATE())), 1) AS edad_promedio
FROM paciente pac
INNER JOIN historiaClinica hc ON pac.id = hc.id_paciente
INNER JOIN o_social os ON hc.id_o_social = os.id
WHERE pac.eliminado = 0 AND hc.eliminado = 0 AND os.eliminado = 0
GROUP BY rango_edad, os.id, os.nombre
ORDER BY rango_edad, cantidad_pacientes DESC;

-- 7. CONSULTA: Pacientes con antecedentes específicos y sus intervenciones recientes
-- (WHERE LIKE + JOIN + Subconsulta correlacionada)
SELECT 
    pac.dni,
    CONCAT(pac.apellido, ', ', pac.nombre) AS paciente,
    hc.antecedentes,
    (SELECT COUNT(*) 
     FROM intervenciones i 
     WHERE i.id_paciente = pac.id 
       AND i.eliminado = 0 
       AND i.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)) AS intervenciones_recientes,
    (SELECT GROUP_CONCAT(DISTINCT m.medicamento SEPARATOR ', ')
     FROM intervenciones i2
     INNER JOIN medicamento_intervenciones mi ON i2.id = mi.id_intervencion
     INNER JOIN medicamentos m ON mi.id_medicamento = m.id
     WHERE i2.id_paciente = pac.id 
       AND i2.eliminado = 0
       AND m.eliminado = 0
       AND i2.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)) AS medicamentos_recientes
FROM paciente pac
INNER JOIN historiaClinica hc ON pac.id = hc.id_paciente
WHERE pac.eliminado = 0 
    AND hc.eliminado = 0
    AND (hc.antecedentes LIKE '%Diabetes%' 
         OR hc.antecedentes LIKE '%Hipertension%'
         OR hc.antecedentes LIKE '%Asma%')
ORDER BY intervenciones_recientes DESC;

-- 8. REPORTE: Resumen mensual de actividad clínica
-- (DATE_FORMAT + GROUP BY + múltiples agregaciones)
SELECT 
    DATE_FORMAT(i.fecha, '%Y-%m') AS mes,
    COUNT(DISTINCT i.id_paciente) AS pacientes_atendidos,
    COUNT(i.id) AS total_intervenciones,
    COUNT(DISTINCT i.id_profesional) AS profesionales_activos,
    COUNT(mi.id_medicamento) AS recetas_emitidas,
    ROUND(COUNT(i.id) / COUNT(DISTINCT i.id_paciente), 2) AS promedio_intervenciones_por_paciente
FROM intervenciones i
LEFT JOIN medicamento_intervenciones mi ON i.id = mi.id_intervencion
WHERE i.eliminado = 0
    AND i.fecha >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH)
GROUP BY DATE_FORMAT(i.fecha, '%Y-%m')
ORDER BY mes DESC;

-- 9. CONSULTA: Pacientes con domicilios completos por provincia
-- (JOIN múltiples + GROUP BY + CONCAT)
SELECT 
    prov.provincia,
    loc.localidad,
    COUNT(DISTINCT pac.id) AS total_pacientes,
    GROUP_CONCAT(
        CONCAT(pac.apellido, ', ', pac.nombre, ' - ', dom.direccion)
        SEPARATOR ' | '
    ) AS pacientes_direcciones
FROM provincia prov
INNER JOIN localidad loc ON prov.id = loc.id_provincia
INNER JOIN domicilio dom ON loc.id = dom.id_localidad
INNER JOIN paciente pac ON dom.id_paciente = pac.id
WHERE prov.eliminado = 0 
    AND loc.eliminado = 0 
    AND dom.eliminado = 0 
    AND pac.eliminado = 0
GROUP BY prov.id, prov.provincia, loc.id, loc.localidad
HAVING total_pacientes > 0
ORDER BY prov.provincia, loc.localidad;

-- 10. REPORTE: Análisis de medicamentos por paciente con antecedentes
-- (Subconsulta compleja + CASE + JOIN)
SELECT 
    CONCAT(pac.apellido, ', ', pac.nombre) AS paciente,
    hc.antecedentes,
    m.medicamento,
    COUNT(mi.id_intervencion) AS veces_recetado,
    CASE 
        WHEN hc.antecedentes LIKE '%Diabetes%' AND m.medicamento IN ('Metformina', 'Insulina', 'Glibenclamida') 
            THEN 'Tratamiento relacionado'
        WHEN hc.antecedentes LIKE '%Hipertension%' AND m.medicamento IN ('Enalapril', 'Losartán', 'Amlodipina') 
            THEN 'Tratamiento relacionado'
        WHEN hc.antecedentes LIKE '%Asma%' AND m.medicamento LIKE '%Salbutamol%' 
            THEN 'Tratamiento relacionado'
        ELSE 'Otro tratamiento'
    END AS tipo_tratamiento
FROM paciente pac
INNER JOIN historiaClinica hc ON pac.id = hc.id_paciente
INNER JOIN intervenciones i ON pac.id = i.id_paciente
INNER JOIN medicamento_intervenciones mi ON i.id = mi.id_intervencion
INNER JOIN medicamentos m ON mi.id_medicamento = m.id
WHERE pac.eliminado = 0 
    AND hc.eliminado = 0 
    AND i.eliminado = 0 
    AND m.eliminado = 0
    AND hc.antecedentes NOT LIKE '%Sin antecedentes%'
GROUP BY pac.id, pac.apellido, pac.nombre, hc.antecedentes, m.id, m.medicamento
ORDER BY veces_recetado DESC;

