-- ============================================
--  03_carga_masiva.sql—
-- ============================================
-- creamos una funcion para generar las localidades asociadas a una provincia.
DELIMITER $$
CREATE PROCEDURE GenerarLocalidades()
BEGIN
SET foreign_key_checks = 0;
INSERT INTO localidad (localidad, id_provincia)
SELECT l.localidad AS localidad,
(SELECT p.id FROM provincia p ORDER BY RAND() LIMIT 1) AS id_provincia
FROM localidades_aux l;
COMMIT;
SET foreign_key_checks = 1;
END$$
DELIMITER ;
-- llamamos a la funcion para generar las localidades.
CALL GenerarLocalidades();
DROP PROCEDURE IF EXISTS GenerarLocalidades; -- BORRAMOS EL PROCEDIMIENTO


-- creamos la funcion para generar los numeros de telefono ficticios de los pacientes.
DELIMITER $$
CREATE PROCEDURE GenerarTelefonosFicticios(IN num_telefonos INT)
BEGIN
DECLARE i INT DEFAULT 0;
DECLARE numero_ficticio VARCHAR(20); -- Se ajusta al VARCHAR(20) de tu tabla
SET @old_foreign_key_checks = @@foreign_key_checks;
SET @old_unique_checks = @@unique_checks;
SET foreign_key_checks = 0;
SET unique_checks = 0;

SET i = 0;
WHILE i < num_telefonos DO
SET numero_ficticio = CONCAT('+54 9 ', LPAD(FLOOR(RAND() * 9999999999), 10, '0'));
INSERT INTO telefono (numero)
VALUES (numero_ficticio);
SET i = i + 1;
END WHILE;
COMMIT;
SET foreign_key_checks = @old_foreign_key_checks;
SET unique_checks = @old_unique_checks;
END$$
DELIMITER ;
-- llamamos a la funcion para generar los telefonos (en el parentesis ingresamos la cantidad deregistros a generar)
CALL GenerarTelefonosFicticios(500);
DROP PROCEDURE IF EXISTS GenerarTelefonosFicticios; -- BORRAMOS ELPROCEDIMIENTO

-- generamos la funcion para crear los pacientes ficticios y las historias clinicas.
DELIMITER $$
CREATE PROCEDURE GenerarPacientes(IN num_registros INT)
BEGIN
DECLARE i INT DEFAULT 0;
DECLARE max_osocial INT DEFAULT 21;
SET foreign_key_checks = 0;
SET unique_checks = 0;
WHILE i < num_registros DO

SET @nombre_rand = (SELECT apellido FROM apellidos_aux ORDER BY

RAND() LIMIT 1);
SET @apellido_rand = (SELECT nombre FROM nombres_aux ORDER BY RAND() LIMIT
1);
SET @dni_ficticio = LPAD(FLOOR(RAND() * 99999999), 8, '0');
SET @fecha_nac = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() * 22630 + 6570)
DAY);

SET @contacto_rand = CONCAT((SELECT nombre FROM nombres_aux

ORDER BY RAND() LIMIT 1), ' ',
(SELECT apellido FROM apellidos_aux ORDER BY RAND() LIMIT 1));
SET @numero_contacto = CONCAT('+54 9 ', LPAD(FLOOR(RAND() * 9999999999), 10,
'0'));
SET @antecedente_rand = (SELECT antecedente FROM antecedentes_aux ORDER BY
RAND() LIMIT 1);
INSERT INTO paciente (apellido, nombre, dni, fecha_nac, email, persona_contacto,
telefono_contacto)
VALUES (
@apellido_rand,
@nombre_rand,
@dni_ficticio,
@fecha_nac,
CONCAT(@nombre_rand,'.', @apellido_rand, '@', 'ficticio.com'),
@contacto_rand,
@numero_contacto);
-- Insertamos la Historia Clínica al mismo tiempo (usando LAST_INSERT_ID() para la FK)
INSERT INTO historiaClinica (id_paciente, nro_historia, grupo_sangre, id_o_social,
antecedentes, observaciones)
VALUES (
LAST_INSERT_ID(),
CONCAT('HC-', LAST_INSERT_ID()),
ELT(FLOOR(1 + (RAND() * 8)), 'A+', 'O-', 'B+', 'AB-', 'O+', 'A-', 'B-', 'AB+'),
FLOOR(1 + (RAND() * max_osocial)),
@antecedente_rand,
'Sin observación');
SET i = i + 1;
END WHILE;
COMMIT;
SET foreign_key_checks = 1;
SET unique_checks = 1;
END$$
DELIMITER ;
-- Llamamos la funcion generadora de registros para la tabla pacientes e historia clínica,(ponemos en los parentesios
-- la cantidad de registros que queremos generar)
CALL GenerarPacientes(1000);
DROP PROCEDURE IF EXISTS GenerarPacientes; -- BORRAMOS EL PROCEDIMIENTO

-- generamos la funcion para los domicilios de los pacientes.

DELIMITER $$
CREATE PROCEDURE GenerarDomicilios()
BEGIN
SET foreign_key_checks = 0;
INSERT INTO domicilio (id_paciente, direccion, id_localidad)
SELECT p.id AS id_paciente,
(SELECT CONCAT(c.calle_nro, ' ', FLOOR(RAND() * 4900) + 100) FROM calles_aux c
ORDER BY RAND() LIMIT 1) AS direccion,
(SELECT l.id FROM localidad l ORDER BY RAND() LIMIT 1) AS id_localidad
FROM paciente p;
COMMIT;
SET foreign_key_checks = 1;
END$$
DELIMITER ;
CALL GenerarDomicilios();
DROP PROCEDURE IF EXISTS GenerarDomicilios; -- BORRAMOS EL PROCEDIMIENTO
-- completamos la tabla profesionales.
DELIMITER $$
CREATE PROCEDURE GenerarProfesionales(IN num_registros INT)
BEGIN
DECLARE i INT DEFAULT 0;

SET foreign_key_checks = 0;
SET unique_checks = 0;
WHILE i < num_registros DO

SET @nombre_rand = (SELECT apellido FROM apellidos_aux ORDER BY

RAND() LIMIT 1);
SET @apellido_rand = (SELECT nombre FROM nombres_aux ORDER BY RAND() LIMIT
1);
SET @id_rand = (SELECT id FROM especialidad ORDER BY RAND() LIMIT 1);
INSERT INTO profesional (nombre, apellido, id_especialidad)
VALUES (
@apellido_rand,
@nombre_rand,
@id_rand);
SET i = i + 1;
END WHILE;
COMMIT;
SET foreign_key_checks = 1;
SET unique_checks = 1;
END$$
DELIMITER ;
-- llamamos a la funcion para generar los profesionales.
CALL GenerarProfesionales(70);
DROP PROCEDURE IF EXISTS GenerarProfesionales; -- BORRAMOS EL PROCEDIMIENTO
-- completamos la tabla intervenciones.
DELIMITER $$
CREATE PROCEDURE GenerarIntervenciones(IN num_registros INT)
BEGIN
DECLARE i INT DEFAULT 0;
SET foreign_key_checks = 0;
SET unique_checks = 0;
WHILE i < num_registros DO

SET @id_pac_rand = (SELECT id FROM paciente ORDER BY RAND() LIMIT 1);

SET @fecha_int_rand = DATE_SUB(CURDATE(), INTERVAL FLOOR(RAND() *

7300) DAY);
SET @id_prof_rand = (SELECT id FROM profesional ORDER BY RAND() LIMIT 1);
INSERT INTO intervenciones (id_paciente, fecha, id_profesional, detalle)
VALUES (
@id_pac_rand,
@fecha_int_rand,
@id_prof_rand,
('Se le practico algo relativo a su dolencia'));
SET i = i + 1;
END WHILE;
COMMIT;
SET foreign_key_checks = 1;
SET unique_checks = 1;
END$$
DELIMITER ;
-- llamamos a la funcion para generar las intervenciones.
CALL GenerarIntervenciones(1000);
DROP PROCEDURE IF EXISTS GenerarIntervenciones; -- BORRAMOS EL
PROCEDIMIENTO

-- completamos la tabla telefono_paciente.
DELIMITER $$
CREATE PROCEDURE GenerarTelefono_Paciente()
BEGIN
DECLARE done INT DEFAULT 0;
DECLARE v_paciente INT;
DECLARE v_telefono INT;
DECLARE cur CURSOR FOR
SELECT p.id, t.id
FROM paciente p
JOIN telefono t ON p.id = t.id
WHERE p.id <= (SELECT COUNT(*) FROM telefono);
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

SET foreign_key_checks = 0;

OPEN cur;
read_loop: LOOP
FETCH cur INTO v_paciente, v_telefono;
IF done THEN

LEAVE read_loop;
END IF;

INSERT INTO telefono_paciente (id_paciente, id_telefono)
VALUES (v_paciente, v_telefono);
END LOOP;

CLOSE cur;
SET foreign_key_checks = 1;
END$$
DELIMITER ;

-- llamamos a la funcion para generar los telefono_paciente.

CALL GenerarTelefono_Paciente();
DROP PROCEDURE IF EXISTS GenerarTelefono_Paciente; -- BORRAMOS EL
PROCEDIMIENTO

-- completamos la tabla medicamento_intervenciones.
DELIMITER $$
CREATE PROCEDURE GenerarMedicamento_Intervenciones()
BEGIN
SET foreign_key_checks = 0;
INSERT INTO medicamento_intervenciones (id_intervencion, id_medicamento)
SELECT i.id AS id_intervencion,
(SELECT m.id FROM medicamentos m ORDER BY RAND() LIMIT 1) AS id_medicamento
FROM intervenciones i;
COMMIT;
SET foreign_key_checks = 1;
END$$
DELIMITER ;
-- llamamos a la funcion para generar los telefono_paciente.
CALL GenerarMedicamento_Intervenciones();
DROP PROCEDURE IF EXISTS GenerarMedicamento_Intervenciones; -- BORRAMOS ELPROCEDIMIENTO
DROP TABLE IF EXISTS calles_aux;
DROP TABLE IF EXISTS apellidos_aux;
DROP TABLE IF EXISTS antecedentes_aux;
DROP TABLE IF EXISTS localidades_aux;
DROP TABLE IF EXISTS nombres_aux;