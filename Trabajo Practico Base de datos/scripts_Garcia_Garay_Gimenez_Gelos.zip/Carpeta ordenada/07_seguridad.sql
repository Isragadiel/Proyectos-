-- ============================================
-- PUNTO 4 - VISTAS "SANITIZADAS" (sin PII/PHI)
-- BD: pacienteHistoriaClinica
-- ============================================

USE pacienteHistoriaClinica;

-- Limpieza defensiva
DROP VIEW IF EXISTS v_pacientes_publico;
DROP VIEW IF EXISTS v_intervenciones_publico;
DROP VIEW IF EXISTS v_estadisticas_profesional_publico;

-- ------------------------------------------------------------------
-- v_pacientes_publico
--   Expone info mínima y no sensible de pacientes
--   Oculta: dni, email, teléfono, fecha_nac cruda, nro_historia,
--           grupo_sangre, antecedentes, observaciones, domicilio, etc.
-- ------------------------------------------------------------------
CREATE OR REPLACE VIEW v_pacientes_publico AS
SELECT
  p.id                                              AS id_paciente,
  CONCAT(p.apellido, ', ', p.nombre)                AS paciente,
  TIMESTAMPDIFF(YEAR, p.fecha_nac, CURDATE())       AS edad,
  os.nombre                                         AS obra_social,
  COUNT(DISTINCT i.id)                              AS cant_intervenciones,
  DATE(MAX(i.fecha))                                AS ultima_intervencion
FROM paciente p
LEFT JOIN historiaClinica hc
       ON hc.id_paciente = p.id       AND hc.eliminado = 0
LEFT JOIN o_social os
       ON os.id = hc.id_o_social      AND os.eliminado = 0
LEFT JOIN intervenciones i
       ON i.id_paciente = p.id        AND i.eliminado = 0
WHERE p.eliminado = 0
GROUP BY p.id, p.apellido, p.nombre, p.fecha_nac, os.nombre;

-- ------------------------------------------------------------------
-- v_intervenciones_publico
--   Expone intervenciones sin detalle clínico
--   Oculta: campo 'detalle' y cualquier PII del paciente
-- ------------------------------------------------------------------
CREATE OR REPLACE VIEW v_intervenciones_publico AS
SELECT
  i.id                                 AS id_intervencion,
  i.id_paciente                        AS id_paciente,      -- ID interno, no PII
  DATE(i.fecha)                        AS fecha,
  CONCAT(pr.apellido, ', ', pr.nombre) AS profesional,
  e.especialidad                       AS especialidad,
  COUNT(mi.id_medicamento)             AS cant_medicamentos
FROM intervenciones i
JOIN profesional pr
  ON pr.id = i.id_profesional AND pr.eliminado = 0
JOIN especialidad e
  ON e.id = pr.id_especialidad AND e.eliminado = 0
LEFT JOIN medicamento_intervenciones mi
  ON mi.id_intervencion = i.id
WHERE i.eliminado = 0
GROUP BY i.id, i.id_paciente, i.fecha, pr.apellido, pr.nombre, e.especialidad;

-- ------------------------------------------------------------------
-- v_estadisticas_profesional_publico
--   Estadísticas agregadas sin exponer pacientes individualmente
-- ------------------------------------------------------------------
CREATE OR REPLACE VIEW v_estadisticas_profesional_publico AS
SELECT
  pr.id                                  AS id_profesional,
  CONCAT(pr.apellido, ', ', pr.nombre)   AS profesional,
  e.especialidad                         AS especialidad,
  COUNT(DISTINCT i.id_paciente)          AS pacientes_atendidos,
  COUNT(i.id)                            AS total_intervenciones,
  COUNT(mi.id_medicamento)               AS recetas_emitidas,
  DATE(MIN(i.fecha))                     AS primera_atencion,
  DATE(MAX(i.fecha))                     AS ultima_atencion
FROM profesional pr
JOIN especialidad e
  ON e.id = pr.id_especialidad AND e.eliminado = 0
LEFT JOIN intervenciones i
  ON i.id_profesional = pr.id AND i.eliminado = 0
LEFT JOIN medicamento_intervenciones mi
  ON mi.id_intervencion = i.id
WHERE pr.eliminado = 0
GROUP BY pr.id, pr.apellido, pr.nombre, e.especialidad;

-- Ejemplos de uso:
-- SELECT * FROM v_pacientes_publico LIMIT 10;
-- SELECT * FROM v_intervenciones_publico ORDER BY fecha DESC LIMIT 10;
-- SELECT * FROM v_estadisticas_profesional_publico ORDER BY total_intervenciones DESC LIMIT 10;


-- ============================================
-- PUNTO 4 - USUARIO DE MÍNIMOS PRIVILEGIOS
-- Solo SELECT sobre vistas sanitizadas
-- ============================================

-- 1) Crear usuario 
DROP USER IF EXISTS 'usuario_reporte'@'%';
CREATE USER 'usuario_reporte'@'%' IDENTIFIED BY 'ClaveNueva';

-- 2) Sin privilegios globales
REVOKE ALL PRIVILEGES, GRANT OPTION FROM 'usuario_reporte'@'%';

-- 3) Otorgar permisos SOLO SELECT sobre las VISTAS (no a tablas base)
GRANT SELECT ON pacienteHistoriaClinica.v_pacientes_publico              TO 'usuario_reporte'@'%';
GRANT SELECT ON pacienteHistoriaClinica.v_intervenciones_publico         TO 'usuario_reporte'@'%';
GRANT SELECT ON pacienteHistoriaClinica.v_estadisticas_profesional_publico TO 'usuario_reporte'@'%';

FLUSH PRIVILEGES;

-- PRUEBAS (logueado como usuario_reporte):
--  OK:   SELECT * FROM pacienteHistoriaClinica.v_pacientes_publico LIMIT 5;
--  OK:   SELECT * FROM pacienteHistoriaClinica.v_intervenciones_publico LIMIT 5;
--  ERROR: SELECT * FROM pacienteHistoriaClinica.paciente;              -- Permiso denegado
--  ERROR: SELECT dni FROM pacienteHistoriaClinica.paciente;            -- Permiso denegado


-- ============================================
-- PUNTO 4 - PRUEBAS DE INTEGRIDAD (ejecutar por bloque)
-- ============================================

-- ------------------------------------------------------------------
-- A) UNIQUE: duplicado de DNI en paciente
--    Ejecutar este bloque completo y observar el error en la 2ª INSERT
-- ------------------------------------------------------------------
SET @dni_test := CONCAT('DUP-', FLOOR(RAND()*1000000));
INSERT INTO paciente (eliminado, apellido, nombre, dni, fecha_nac, email, persona_contacto, telefono_contacto)
VALUES (0, 'Prueba', 'UnicoOK', @dni_test, '1990-01-01', 'uno@example.com', 'N/A', 'N/A');
-- Debe fallar por UNIQUE (dni):
INSERT INTO paciente (eliminado, apellido, nombre, dni, fecha_nac, email, persona_contacto, telefono_contacto)
VALUES (0, 'Prueba', 'UnicoFAIL', @dni_test, '1991-02-02', 'dos@example.com', 'N/A', 'N/A');

-- ------------------------------------------------------------------
-- B) FOREIGN KEY: domicilio con FK inexistentes
--    Ejecutar por separado; debe fallar por FK
-- ------------------------------------------------------------------
INSERT INTO domicilio (eliminado, id_paciente, direccion, id_localidad)
VALUES (0, 9999999, 'Calle Falsa 123', 9999999);  -- IDs inexistentes → error FK

-- ------------------------------------------------------------------
-- C) CHECK: valor inválido en 'eliminado' (debe ser 0 o 1)
--    Ejecutar por separado; debe fallar por CHECK
-- ------------------------------------------------------------------
INSERT INTO especialidad (eliminado, especialidad)
VALUES (2, 'Chequeo CHECK inválido');  -- 2 viola CHECK (eliminado IN (0,1))

-- ------------------------------------------------------------------
-- D) TRIGGER temporal: fecha futura en intervenciones
--    Requiere que exista al menos un paciente y un profesional
-- ------------------------------------------------------------------
SET @any_paciente := (SELECT id FROM paciente WHERE eliminado = 0 ORDER BY id LIMIT 1);
SET @any_prof     := (SELECT id FROM profesional WHERE eliminado = 0 ORDER BY id LIMIT 1);

-- Verificá que no sean NULL:
SELECT @any_paciente AS paciente_ejemplo, @any_prof AS profesional_ejemplo;

-- Debe fallar por el trigger (fecha futura):
INSERT INTO intervenciones (eliminado, id_paciente, fecha, id_profesional, detalle)
VALUES (0, @any_paciente, DATE_ADD(CURDATE(), INTERVAL 1 DAY), @any_prof, 'Prueba fecha futura');


-- ============================================
-- PUNTO 4 - CONSULTA SEGURA (Procedimiento almacenado)
-- Sin SQL dinámico; parámetros tipados evitan inyección
-- ============================================

DELIMITER $$

DROP PROCEDURE IF EXISTS sp_buscar_intervenciones_por_paciente $$
CREATE PROCEDURE sp_buscar_intervenciones_por_paciente(
  IN p_id_paciente     INT,
  IN p_desde           DATE,
  IN p_hasta           DATE,
  IN p_id_especialidad INT  -- puede ser NULL para "todas"
)
BEGIN
  /*
    Devuelve intervenciones de un paciente entre fechas, opcionalmente
    filtradas por especialidad del profesional. No incluye 'detalle'.
    Seguridad:
      - Parámetros tipados (INT/DATE) ⇒ el motor castea y NO interpreta
        cadenas maliciosas como código SQL.
      - No se usa SQL dinámico; NO hay concatenación de strings en la consulta.
  */
  SELECT
    i.id                                   AS id_intervencion,
    DATE(i.fecha)                          AS fecha,
    i.id_paciente                          AS id_paciente,
    CONCAT(pr.apellido, ', ', pr.nombre)   AS profesional,
    e.especialidad                         AS especialidad
  FROM intervenciones i
  JOIN profesional pr
    ON pr.id = i.id_profesional AND pr.eliminado = 0
  JOIN especialidad e
    ON e.id = pr.id_especialidad AND e.eliminado = 0
  WHERE
    i.eliminado = 0
    AND i.id_paciente = p_id_paciente
    AND DATE(i.fecha) BETWEEN p_desde AND p_hasta
    AND (p_id_especialidad IS NULL OR pr.id_especialidad = p_id_especialidad)
  ORDER BY i.fecha DESC;
END $$
DELIMITER ;

-- --------------------------------------------
-- PRUEBAS (ejecutar ejemplos, descomentar la línea)
-- --------------------------------------------

-- Ejemplo normal (ajustar ID/fechasActualizarPacienteRetry):
-- CALL sp_buscar_intervenciones_por_paciente(1, '2024-01-01', '2025-12-31', NULL);

-- Anti-inyección (intento malicioso):
--   La cadena '1 OR 1=1 --' se envía al parámetro INT y el motor la castea → 1
--   No se altera el WHERE; NO devuelve "todo".
--   Resultado esperado: mismo efecto que pasar 1, o error de casteo según configuración.
-- CALL sp_buscar_intervenciones_por_paciente('1 OR 1=1 --', '2024-01-01', '2025-12-31', NULL);

-- Filtro por especialidad (ej.: Clínica Médica):
-- SELECT id FROM especialidad WHERE especialidad LIKE 'Clínica Médica' LIMIT 1;
-- SET @esp := (SELECT id FROM especialidad WHERE especialidad LIKE 'Clínica Médica' LIMIT 1);
-- CALL sp_buscar_intervenciones_por_paciente(1, '2024-01-01', '2025-12-31', @esp);
